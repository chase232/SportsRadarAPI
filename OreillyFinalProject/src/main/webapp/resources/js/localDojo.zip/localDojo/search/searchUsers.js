define('local/search/searchUsers', [], function () {
	console.log('search users');
	const module = {};
	
	module.startSearch = function () {
		return 'hola';
	}
	return module;
})